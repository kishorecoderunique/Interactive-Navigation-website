/* ==========================================================================
   NavCraft - Interactivity (script.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

    /* --- 1. Dynamic Navbar scroll effects --- */
    const navbar = document.getElementById('navbar');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    /* --- 2. Mobile Drawer Navigation Toggle --- */
    const hamburgerToggle = document.getElementById('hamburger-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    
    hamburgerToggle.addEventListener('click', () => {
        // Toggle 'open' class to trigger Hamburger 'X' animation
        hamburgerToggle.classList.toggle('open');
        // Toggle 'active' class on Drawer to slide menu down
        mobileMenu.classList.toggle('active');
    });

    // Close mobile menu whenever clicking a mobile nav item
    const mobileLinks = document.querySelectorAll('.mobile-nav-item');
    mobileLinks.forEach(link => {
        link.addEventListener('click', () => {
            hamburgerToggle.classList.remove('open');
            mobileMenu.classList.remove('active');
        });
    });

    /* --- 3. Dynamic Active Navigation Indicator (ScrollSpy) --- */
    const sections = document.querySelectorAll('section[id]');
    const navItems = document.querySelectorAll('.nav-item');
    const mobileNavItems = document.querySelectorAll('.mobile-nav-item');

    function highlightActiveLink() {
        const scrollPosition = window.scrollY + 120; // offset for sticky navbar

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                // Update desktop links
                navItems.forEach(item => {
                    item.classList.remove('active');
                    if (item.getAttribute('href') === '#' + sectionId) {
                        item.classList.add('active');
                    }
                });

                // Update mobile drawer links
                mobileNavItems.forEach(item => {
                    item.classList.remove('active');
                    if (item.getAttribute('href') === '#' + sectionId) {
                        item.classList.add('active');
                    }
                });
            }
        });
    }

    window.addEventListener('scroll', highlightActiveLink);
    // Trigger on initial load to set default active tab
    highlightActiveLink();

    /* --- 4. Portfolio Filter System --- */
    const filterButtons = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            // Remove active class from current active button
            document.querySelector('.filter-btn.active').classList.remove('active');
            e.target.classList.add('active');

            const selectedFilter = e.target.getAttribute('data-filter');

            portfolioItems.forEach(item => {
                const itemCategory = item.getAttribute('data-category');

                // Smooth fade effects
                if (selectedFilter === 'all' || itemCategory === selectedFilter) {
                    item.style.display = 'block';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'scale(1)';
                    }, 50);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 300); // match transition speed
                }
            });
        });
    });

    /* --- 5. Clean Smooth Scroll with offset offset --- */
    const allAnchorLinks = document.querySelectorAll('a[href^="#"]');
    
    allAnchorLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href');
            if (targetId === '#') return;

            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                e.preventDefault();
                
                const navbarHeight = 70; // scrolled navbar height offset
                const targetPosition = targetSection.offsetTop - navbarHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    /* --- 6. Form Submit Interceptor --- */
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Collect info safely
            const name = document.getElementById('name').value;
            
            // Style-up a beautiful inline success card
            const contactCard = document.querySelector('.contact-card');
            contactCard.innerHTML = `
                <div style="text-align: center; padding: 20px; display: flex; flex-direction: column; align-items: center; gap: 16px;">
                    <div style="width: 60px; height: 60px; background-color: var(--color-primary-glow); color: var(--color-primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px;">
                        <i class="fa-solid fa-circle-check"></i>
                    </div>
                    <h3 style="font-size: 22px; color: var(--color-text-title);">Thank you, ${name}!</h3>
                    <p style="font-size: 15px; color: var(--color-text-muted); line-height: 1.6;">Your message has been received successfully. Our design team will reach out to you shortly.</p>
                </div>
            `;
        });
    }
});

export const htmlCode = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NavCraft - Premium Navigation Experience</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <!-- FontAwesome Icons (for visual styling) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Header / Fixed Navigation -->
    <header class="navbar-container" id="navbar">
        <div class="navbar-wrapper">
            <!-- Logo -->
            <a href="#home" class="logo">
                <div class="logo-icon">
                    <i class="fa-solid fa-compass"></i>
                </div>
                <span class="logo-text">Nav<span class="accent-text">Craft</span></span>
            </a>

            <!-- Desktop Nav Links -->
            <nav class="nav-links">
                <a href="#home" class="nav-item active">Home</a>
                <a href="#about" class="nav-item">About</a>
                <a href="#services" class="nav-item">Services</a>
                <a href="#portfolio" class="nav-item">Portfolio</a>
                <a href="#contact" class="nav-item">Contact</a>
            </nav>

            <!-- CTA Buttons (Desktop) -->
            <div class="nav-actions">
                <button class="btn btn-login">Log In</button>
                <button class="btn btn-signup">Sign Up</button>
            </div>

            <!-- Hamburger Button (Mobile) -->
            <button class="hamburger" id="hamburger-toggle" aria-label="Toggle navigation">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
        </div>

        <!-- Mobile Menu (Collapsible Drawer) -->
        <div class="mobile-menu" id="mobile-menu">
            <nav class="mobile-nav-links">
                <a href="#home" class="mobile-nav-item">Home</a>
                <a href="#about" class="mobile-nav-item">About</a>
                <a href="#services" class="mobile-nav-item">Services</a>
                <a href="#portfolio" class="mobile-nav-item">Portfolio</a>
                <a href="#contact" class="mobile-nav-item">Contact</a>
            </nav>
            <div class="mobile-actions">
                <button class="btn btn-login w-full">Log In</button>
                <button class="btn btn-signup w-full">Sign Up</button>
            </div>
        </div>
    </header>

    <!-- Sections below Navbar -->
    <main>
        <!-- Hero Section -->
        <section id="home" class="section hero-section">
            <div class="hero-bg-glow glow-1"></div>
            <div class="hero-bg-glow glow-2"></div>
            <div class="container hero-container">
                <div class="hero-content">
                    <span class="badge">Next-Gen Interface Design</span>
                    <h1 class="hero-title">Experience Seamless <span class="gradient-text">Navigation</span></h1>
                    <p class="hero-description">Elevate your web experiences with smooth scrolling, glassmorphic styling, and fully responsive interactions designed to engage and convert.</p>
                    <div class="hero-buttons">
                        <a href="#services" class="btn btn-primary">Explore Services</a>
                        <a href="#about" class="btn btn-secondary">Learn More</a>
                    </div>
                </div>
                <div class="hero-visual">
                    <div class="glass-card-mockup">
                        <div class="mockup-header">
                            <span class="dot red"></span>
                            <span class="dot yellow"></span>
                            <span class="dot green"></span>
                        </div>
                        <div class="mockup-body">
                            <div class="mockup-line-large"></div>
                            <div class="mockup-line-medium"></div>
                            <div class="mockup-grid">
                                <div class="mockup-grid-box"></div>
                                <div class="mockup-grid-box"></div>
                                <div class="mockup-grid-box"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section id="about" class="section about-section">
            <div class="container">
                <div class="section-header">
                    <span class="section-tag">About Our Craft</span>
                    <h2 class="section-title">Designed for Visual Perfection</h2>
                    <p class="section-subtitle">We build premium interaction layers that connect human intuition with technical elegance.</p>
                </div>
                <div class="about-grid">
                    <div class="about-card">
                        <div class="about-icon"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
                        <h3>Pixel Perfect</h3>
                        <p>Every element is aligned to a strict visual grid with balanced proportions and elegant spacing.</p>
                    </div>
                    <div class="about-card">
                        <div class="about-icon"><i class="fa-solid fa-bolt"></i></div>
                        <h3>Lightning Fast</h3>
                        <p>Fully optimized CSS transitions and minimal JS overhead mean animations run at a locked 60fps.</p>
                    </div>
                    <div class="about-card">
                        <div class="about-icon"><i class="fa-solid fa-mobile-screen"></i></div>
                        <h3>Universal Layout</h3>
                        <p>Adapts flawlessly to any display, from massive 4K monitors down to compact mobile viewports.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Services Section -->
        <section id="services" class="section services-section">
            <div class="container">
                <div class="section-header">
                    <span class="section-tag">What We Do</span>
                    <h2 class="section-title">Our Navigation Services</h2>
                    <p class="section-subtitle">Tailored interaction patterns engineered specifically for your business applications.</p>
                </div>
                <div class="services-grid">
                    <div class="service-bento-card large">
                        <div class="bento-content">
                            <span class="bento-badge">Premium Feature</span>
                            <h3>Custom Navigation Audits</h3>
                            <p>We review your user journeys, click tracking, and information hierarchy to create standard layouts that drive conversions.</p>
                        </div>
                        <div class="bento-graphic">
                            <i class="fa-solid fa-chart-line"></i>
                        </div>
                    </div>
                    <div class="service-bento-card">
                        <div class="bento-content">
                            <h3>Micro-Interactions</h3>
                            <p>Delightful feedback animations for buttons, menus, and forms that elevate the app experience.</p>
                        </div>
                        <div class="bento-graphic mini">
                            <i class="fa-solid fa-fingerprint"></i>
                        </div>
                    </div>
                    <div class="service-bento-card">
                        <div class="bento-content">
                            <h3>Responsive Auditing</h3>
                            <p>Ensuring your complex nested desktop dropdown menus degrade beautifully on tiny screens.</p>
                        </div>
                        <div class="bento-graphic mini">
                            <i class="fa-solid fa-crop-simple"></i>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Portfolio Section -->
        <section id="portfolio" class="section portfolio-section">
            <div class="container">
                <div class="section-header">
                    <span class="section-tag">Featured Work</span>
                    <h2 class="section-title">Visual Showcase</h2>
                    <p class="section-subtitle">Explore a selection of interaction patterns and high-performance layouts we have crafted.</p>
                </div>
                
                <!-- Portfolio Filter Controls -->
                <div class="portfolio-filter">
                    <button class="filter-btn active" data-filter="all">All Projects</button>
                    <button class="filter-btn" data-filter="glass">Glassmorphism</button>
                    <button class="filter-btn" data-filter="minimal">Minimalist</button>
                    <button class="filter-btn" data-filter="dynamic">Dynamic UI</button>
                </div>

                <div class="portfolio-grid" id="portfolio-grid">
                    <div class="portfolio-item" data-category="glass">
                        <div class="portfolio-image">
                            <img src="https://picsum.photos/seed/glass1/600/400" alt="Glassmorphic Dashboard" />
                            <div class="portfolio-overlay">
                                <h3>Glassmorphic Panel</h3>
                                <p>Blur-heavy administration console</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item" data-category="minimal">
                        <div class="portfolio-image">
                            <img src="https://picsum.photos/seed/min1/600/400" alt="Minimal Portfolio" />
                            <div class="portfolio-overlay">
                                <h3>Slate Workspace</h3>
                                <p>Sleek, high-contrast creative deck</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item" data-category="dynamic">
                        <div class="portfolio-image">
                            <img src="https://picsum.photos/seed/dyn1/600/400" alt="Dynamic Navigation" />
                            <div class="portfolio-overlay">
                                <h3>Nebula Portal</h3>
                                <p>Interactive navigation with particle physics</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item" data-category="glass">
                        <div class="portfolio-image">
                            <img src="https://picsum.photos/seed/glass2/600/400" alt="Ambient Interface" />
                            <div class="portfolio-overlay">
                                <h3>Aurora Settings</h3>
                                <p>Soft-glowing system components</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item" data-category="minimal">
                        <div class="portfolio-image">
                            <img src="https://picsum.photos/seed/min2/600/400" alt="Clean Typography" />
                            <div class="portfolio-overlay">
                                <h3>Editorial Hub</h3>
                                <p>High-contrast, elegant serif layouts</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item" data-category="dynamic">
                        <div class="portfolio-image">
                            <img src="https://picsum.photos/seed/dyn2/600/400" alt="Fluid Layout" />
                            <div class="portfolio-overlay">
                                <h3>Responsive Grid</h3>
                                <p>Infinite masonry feed with transitions</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section id="contact" class="section contact-section">
            <div class="container contact-container">
                <div class="contact-info">
                    <span class="section-tag">Get in Touch</span>
                    <h2 class="section-title">Let's craft something amazing together</h2>
                    <p class="contact-text">Have a project in mind or need professional UI/UX consulting? Fill out the form and our design team will get back to you within 24 hours.</p>
                    <div class="contact-details">
                        <div class="contact-detail-item">
                            <i class="fa-solid fa-envelope"></i>
                            <span>design@navcraft.io</span>
                        </div>
                        <div class="contact-detail-item">
                            <i class="fa-solid fa-map-location-dot"></i>
                            <span>San Francisco, California, US</span>
                        </div>
                    </div>
                </div>
                <div class="contact-card">
                    <form class="contact-form" id="contact-form">
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" id="name" required placeholder="John Doe">
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" required placeholder="john@example.com">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea id="message" rows="4" required placeholder="Tell us about your project..."></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-full">Send Message</button>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="main-footer">
        <div class="container footer-content">
            <p>&copy; 2026 NavCraft. All rights reserved. Built with passion, HTML, CSS, and JS.</p>
        </div>
    </footer>

    <!-- Custom Script -->
    <script src="script.js"></script>
</body>
</html>`;

export const cssCode = `/* ==========================================================================
   NavCraft - Stylesheet (style.css)
   ========================================================================== */

/* --- Custom Theme System & Reset --- */
:root {
    /* Color Palette (Emerald & Slate Theme) */
    --color-primary: #10b981;      /* Emerald */
    --color-primary-dark: #059669; /* Darker Emerald */
    --color-primary-glow: rgba(16, 185, 129, 0.15);
    
    --color-bg-base: #f8fafc;      /* Slate 50 */
    --color-bg-card: #ffffff;
    --color-bg-navbar: rgba(255, 255, 255, 0.7); /* Translucent Glass */
    --color-bg-navbar-scrolled: rgba(255, 255, 255, 0.9);
    
    --color-text-title: #0f172a;   /* Slate 900 */
    --color-text-main: #334155;    /* Slate 700 */
    --color-text-muted: #64748b;   /* Slate 500 */
    --color-text-light: #ffffff;
    
    --color-border: #e2e8f0;       /* Slate 200 */
    --color-shadow: rgba(15, 23, 42, 0.06);
    --color-shadow-scrolled: rgba(15, 23, 42, 0.12);
    
    /* Animation Timings */
    --transition-fast: 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    --transition-smooth: 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    
    /* Heights */
    --navbar-height-initial: 90px;
    --navbar-height-scrolled: 70px;
}

/* Base Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
    scroll-padding-top: var(--navbar-height-scrolled);
    font-family: 'Inter', sans-serif;
    background-color: var(--color-bg-base);
    color: var(--color-text-main);
}

body {
    overflow-x: hidden;
}

h1, h2, h3, h4 {
    font-family: 'Space Grotesk', sans-serif;
    color: var(--color-text-title);
    font-weight: 700;
}

p {
    line-height: 1.7;
}

a {
    text-decoration: none;
    color: inherit;
    transition: var(--transition-fast);
}

ul {
    list-style: none;
}

.container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
}

.section {
    padding: 100px 0;
    position: relative;
}

/* ==========================================================================
   Header & Navigation (Fixed at top, Glassmorphism)
   ========================================================================== */
.navbar-container {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: var(--navbar-height-initial);
    background-color: var(--color-bg-navbar);
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    z-index: 1000;
    display: flex;
    align-items: center;
    transition: var(--transition-smooth);
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.02);
}

/* Scrolled Navbar Style */
.navbar-container.scrolled {
    height: var(--navbar-height-scrolled);
    background-color: var(--color-bg-navbar-scrolled);
    box-shadow: 0 10px 30px var(--color-shadow-scrolled);
    border-bottom: 1px solid var(--color-border);
}

.navbar-wrapper {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    max-width: 1280px;
    margin: 0 auto;
    padding: 0 24px;
}

/* Logo */
.logo {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 22px;
    font-weight: 700;
    color: var(--color-text-title);
    transform: scale(1);
    transition: var(--transition-smooth);
}

.logo:hover {
    transform: scale(1.03);
}

.logo-icon {
    width: 36px;
    height: 36px;
    background-color: var(--color-primary);
    color: var(--color-text-light);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    box-shadow: 0 4px 12px var(--color-primary-glow);
}

.accent-text {
    color: var(--color-primary);
}

/* Desktop Nav Links */
.nav-links {
    display: flex;
    align-items: center;
    gap: 32px;
}

.nav-item {
    font-size: 15px;
    font-weight: 500;
    color: var(--color-text-main);
    padding: 8px 4px;
    position: relative;
    transition: var(--transition-fast);
}

/* Hover & Active Effects */
.nav-item:hover, 
.nav-item.active {
    color: var(--color-primary);
    transform: scale(1.05);
}

/* Underline Animation */
.nav-item::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 2px;
    background-color: var(--color-primary);
    transform: scaleX(0);
    transform-origin: right;
    transition: transform var(--transition-smooth);
}

.nav-item:hover::after,
.nav-item.active::after {
    transform: scaleX(1);
    transform-origin: left;
}

/* CTA Buttons & Action Styles */
.nav-actions {
    display: flex;
    align-items: center;
    gap: 16px;
}

.btn {
    font-family: 'Inter', sans-serif;
    font-size: 14px;
    font-weight: 600;
    padding: 10px 22px;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    transition: var(--transition-smooth);
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.btn-login {
    background: transparent;
    color: var(--color-text-main);
    border: 1px solid var(--color-border);
}

.btn-login:hover {
    background-color: rgba(15, 23, 42, 0.04);
    border-color: var(--color-text-muted);
}

.btn-signup {
    background-color: var(--color-primary);
    color: var(--color-text-light);
    box-shadow: 0 4px 14px var(--color-primary-glow);
}

.btn-signup:hover {
    background-color: var(--color-primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px var(--color-primary-glow);
}

/* Hamburger Button */
.hamburger {
    display: none;
    flex-direction: column;
    justify-content: space-between;
    width: 24px;
    height: 18px;
    background: transparent;
    border: none;
    cursor: pointer;
    z-index: 1001;
}

.hamburger .bar {
    width: 100%;
    height: 2.5px;
    background-color: var(--color-text-title);
    border-radius: 5px;
    transition: var(--transition-smooth);
}

/* Hamburger transition to 'X' */
.hamburger.open .bar:nth-child(1) {
    transform: translateY(7.5px) rotate(45deg);
}

.hamburger.open .bar:nth-child(2) {
    opacity: 0;
}

.hamburger.open .bar:nth-child(3) {
    transform: translateY(-7.5px) rotate(-45deg);
}

/* Mobile Nav Drawer */
.mobile-menu {
    position: absolute;
    top: 100%;
    left: 0;
    width: 100%;
    background-color: var(--color-bg-card);
    border-bottom: 1px solid var(--color-border);
    padding: 24px;
    display: flex;
    flex-direction: column;
    gap: 24px;
    opacity: 0;
    visibility: hidden;
    transform: translateY(-10px);
    transition: var(--transition-smooth);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
}

.mobile-menu.active {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.mobile-nav-links {
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.mobile-nav-item {
    font-size: 16px;
    font-weight: 600;
    color: var(--color-text-title);
    padding: 8px 0;
    border-bottom: 1px solid #f1f5f9;
}

.mobile-nav-item.active {
    color: var(--color-primary);
}

.mobile-actions {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

/* ==========================================================================
   Hero Section Layout
   ========================================================================== */
.hero-section {
    padding-top: 180px;
    min-height: 100vh;
    display: flex;
    align-items: center;
    background-color: #0f172a; /* Tech Dark contrast */
    color: var(--color-text-light);
    overflow: hidden;
}

/* Tech dark text fixes */
.hero-section h1 {
    color: var(--color-text-light);
}

.hero-bg-glow {
    position: absolute;
    width: 400px;
    height: 400px;
    border-radius: 50%;
    filter: blur(100px);
    opacity: 0.15;
    pointer-events: none;
    z-index: 1;
}

.glow-1 {
    top: 10%;
    left: 10%;
    background: var(--color-primary);
}

.glow-2 {
    bottom: 10%;
    right: 10%;
    background: #3b82f6; /* Cyan-blue accent */
}

.hero-container {
    display: grid;
    grid-template-columns: 1.2fr 0.8fr;
    gap: 48px;
    align-items: center;
    position: relative;
    z-index: 2;
}

.hero-content {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.badge {
    background-color: rgba(16, 185, 129, 0.1);
    color: var(--color-primary);
    border: 1px solid rgba(16, 185, 129, 0.2);
    font-size: 12px;
    font-weight: 600;
    padding: 6px 14px;
    border-radius: 30px;
    margin-bottom: 24px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.hero-title {
    font-size: 56px;
    line-height: 1.1;
    margin-bottom: 20px;
    letter-spacing: -1px;
}

.gradient-text {
    background: linear-gradient(135deg, var(--color-primary) 0%, #10b981 50%, #3b82f6 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.hero-description {
    font-size: 18px;
    color: #94a3b8; /* Cool Muted Text */
    margin-bottom: 36px;
    max-width: 540px;
}

.hero-buttons {
    display: flex;
    gap: 16px;
}

.btn-primary {
    background-color: var(--color-primary);
    color: var(--color-text-light);
    padding: 14px 28px;
    border-radius: 12px;
    font-weight: 600;
    box-shadow: 0 4px 14px var(--color-primary-glow);
}

.btn-primary:hover {
    background-color: var(--color-primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px var(--color-primary-glow);
}

.btn-secondary {
    background-color: rgba(255, 255, 255, 0.05);
    color: var(--color-text-light);
    border: 1px solid rgba(255, 255, 255, 0.1);
    padding: 14px 28px;
    border-radius: 12px;
    font-weight: 600;
}

.btn-secondary:hover {
    background-color: rgba(255, 255, 255, 0.1);
    transform: translateY(-2px);
}

/* Glassmorphic card graphic */
.hero-visual {
    display: flex;
    justify-content: center;
}

.glass-card-mockup {
    width: 340px;
    height: 380px;
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-radius: 24px;
    padding: 24px;
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
    display: flex;
    flex-direction: column;
    gap: 20px;
    animation: floatingMockup 6s ease-in-out infinite;
}

@keyframes floatingMockup {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-12px); }
}

.mockup-header {
    display: flex;
    gap: 6px;
}

.mockup-header .dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
}

.dot.red { background-color: #ef4444; }
.dot.yellow { background-color: #f59e0b; }
.dot.green { background-color: #10b981; }

.mockup-body {
    display: flex;
    flex-direction: column;
    gap: 16px;
    height: 100%;
}

.mockup-line-large {
    height: 16px;
    width: 80%;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 6px;
}

.mockup-line-medium {
    height: 12px;
    width: 60%;
    background: rgba(255, 255, 255, 0.04);
    border-radius: 6px;
}

.mockup-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-top: auto;
    margin-bottom: 24px;
}

.mockup-grid-box {
    aspect-ratio: 1;
    background: rgba(16, 185, 129, 0.1);
    border: 1px solid rgba(16, 185, 129, 0.2);
    border-radius: 12px;
}

/* ==========================================================================
   Section Headers & Grids
   ========================================================================== */
.section-header {
    text-align: center;
    max-width: 640px;
    margin: 0 auto 60px;
}

.section-tag {
    color: var(--color-primary);
    font-size: 13px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    display: block;
    margin-bottom: 12px;
}

.section-title {
    font-size: 38px;
    line-height: 1.2;
    margin-bottom: 16px;
}

.section-subtitle {
    font-size: 16px;
    color: var(--color-text-muted);
}

/* About Section */
.about-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 32px;
}

.about-card {
    background-color: var(--color-bg-card);
    border: 1px solid var(--color-border);
    border-radius: 20px;
    padding: 40px 32px;
    transition: var(--transition-smooth);
    box-shadow: 0 4px 20px var(--color-shadow);
}

.about-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(15, 23, 42, 0.08);
    border-color: rgba(16, 185, 129, 0.3);
}

.about-icon {
    width: 48px;
    height: 48px;
    background-color: var(--color-primary-glow);
    color: var(--color-primary);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    margin-bottom: 24px;
}

.about-card h3 {
    font-size: 20px;
    margin-bottom: 14px;
}

.about-card p {
    font-size: 15px;
    color: var(--color-text-muted);
}

/* Services Bento Grid */
.services-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
}

.service-bento-card {
    background-color: var(--color-bg-card);
    border: 1px solid var(--color-border);
    border-radius: 24px;
    padding: 36px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: var(--transition-smooth);
    overflow: hidden;
    position: relative;
    box-shadow: 0 4px 20px var(--color-shadow);
}

.service-bento-card:hover {
    transform: translateY(-6px);
    border-color: rgba(16, 185, 129, 0.3);
    box-shadow: 0 15px 35px rgba(15, 23, 42, 0.08);
}

.service-bento-card.large {
    grid-column: span 2;
    flex-direction: row;
    gap: 40px;
    align-items: center;
}

.bento-content {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.bento-badge {
    background-color: var(--color-primary-glow);
    color: var(--color-primary);
    font-size: 11px;
    font-weight: 700;
    padding: 4px 10px;
    border-radius: 30px;
    margin-bottom: 16px;
}

.service-bento-card h3 {
    font-size: 22px;
    margin-bottom: 12px;
}

.service-bento-card p {
    font-size: 14px;
    color: var(--color-text-muted);
}

.bento-graphic {
    font-size: 64px;
    color: rgba(16, 185, 129, 0.15);
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 100px;
}

.bento-graphic.mini {
    align-self: flex-end;
    font-size: 40px;
    margin-top: 24px;
}

/* ==========================================================================
   Portfolio Filtering Layout
   ========================================================================== */
.portfolio-filter {
    display: flex;
    justify-content: center;
    gap: 12px;
    margin-bottom: 48px;
}

.filter-btn {
    background-color: var(--color-bg-card);
    border: 1px solid var(--color-border);
    color: var(--color-text-main);
    padding: 10px 20px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition-fast);
}

.filter-btn:hover {
    background-color: #f1f5f9;
}

.filter-btn.active {
    background-color: var(--color-primary);
    color: var(--color-text-light);
    border-color: var(--color-primary);
    box-shadow: 0 4px 12px var(--color-primary-glow);
}

.portfolio-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
}

.portfolio-item {
    border-radius: 20px;
    overflow: hidden;
    position: relative;
    box-shadow: 0 4px 15px var(--color-shadow);
    background-color: var(--color-bg-card);
    transition: var(--transition-smooth);
}

.portfolio-image {
    width: 100%;
    aspect-ratio: 3/2;
    position: relative;
    overflow: hidden;
}

.portfolio-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
}

.portfolio-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(to top, rgba(15, 23, 42, 0.9) 10%, rgba(15, 23, 42, 0.4) 100%);
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: 24px;
    opacity: 0;
    visibility: hidden;
    transition: var(--transition-smooth);
    color: var(--color-text-light);
}

.portfolio-overlay h3 {
    color: var(--color-text-light);
    font-size: 18px;
    margin-bottom: 4px;
}

.portfolio-overlay p {
    font-size: 13px;
    color: #cbd5e1;
}

/* Hover States */
.portfolio-item:hover {
    transform: translateY(-6px);
}

.portfolio-item:hover img {
    transform: scale(1.1);
}

.portfolio-item:hover .portfolio-overlay {
    opacity: 1;
    visibility: visible;
}

/* ==========================================================================
   Contact Form Styles
   ========================================================================== */
.contact-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 60px;
    align-items: center;
}

.contact-info .section-title {
    text-align: left;
    margin-bottom: 24px;
}

.contact-text {
    font-size: 16px;
    color: var(--color-text-muted);
    margin-bottom: 36px;
}

.contact-details {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.contact-detail-item {
    display: flex;
    align-items: center;
    gap: 16px;
}

.contact-detail-item i {
    width: 44px;
    height: 44px;
    background-color: var(--color-primary-glow);
    color: var(--color-primary);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
}

.contact-detail-item span {
    font-size: 15px;
    font-weight: 500;
}

.contact-card {
    background-color: var(--color-bg-card);
    border: 1px solid var(--color-border);
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 10px 30px var(--color-shadow);
}

.contact-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.form-group label {
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--color-text-title);
}

.form-group input,
.form-group textarea {
    font-family: 'Inter', sans-serif;
    font-size: 14px;
    padding: 12px 16px;
    border-radius: 10px;
    border: 1px solid var(--color-border);
    background-color: #f8fafc;
    transition: var(--transition-fast);
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    background-color: var(--color-bg-card);
    border-color: var(--color-primary);
    box-shadow: 0 0 0 4px var(--color-primary-glow);
}

.w-full {
    width: 100%;
}

/* ==========================================================================
   Footer
   ========================================================================== */
.main-footer {
    background-color: #0f172a;
    color: #94a3b8;
    padding: 40px 0;
    border-top: 1px solid rgba(255, 255, 255, 0.05);
    text-align: center;
    font-size: 14px;
}

/* ==========================================================================
   Responsive Breakpoints
   ========================================================================== */
@media (max-width: 992px) {
    .about-grid,
    .services-grid,
    .portfolio-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .service-bento-card.large {
        grid-column: span 2;
    }
    
    .contact-container {
        grid-template-columns: 1fr;
        gap: 48px;
    }
}

@media (max-width: 768px) {
    :root {
        --navbar-height-initial: 70px;
        --navbar-height-scrolled: 70px;
    }
    
    .nav-links,
    .nav-actions {
        display: none;
    }
    
    .hamburger {
        display: flex;
    }
    
    .hero-container {
        grid-template-columns: 1fr;
        text-align: center;
        justify-items: center;
        gap: 40px;
    }
    
    .hero-content {
        align-items: center;
    }
    
    .hero-title {
        font-size: 40px;
    }
    
    .hero-description {
        font-size: 16px;
    }
    
    .about-grid,
    .services-grid,
    .portfolio-grid {
        grid-template-columns: 1fr;
    }
    
    .service-bento-card.large {
        grid-column: span 1;
        flex-direction: column;
        align-items: flex-start;
    }
}
`;

export const jsCode = `/* ==========================================================================
   NavCraft - Interactivity (script.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

    /* --- 1. Dynamic Navbar scroll effects --- */
    const navbar = document.getElementById('navbar');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    /* --- 2. Mobile Drawer Navigation Toggle --- */
    const hamburgerToggle = document.getElementById('hamburger-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    
    hamburgerToggle.addEventListener('click', () => {
        // Toggle 'open' class to trigger Hamburger 'X' animation
        hamburgerToggle.classList.toggle('open');
        // Toggle 'active' class on Drawer to slide menu down
        mobileMenu.classList.toggle('active');
    });

    // Close mobile menu whenever clicking a mobile nav item
    const mobileLinks = document.querySelectorAll('.mobile-nav-item');
    mobileLinks.forEach(link => {
        link.addEventListener('click', () => {
            hamburgerToggle.classList.remove('open');
            mobileMenu.classList.remove('active');
        });
    });

    /* --- 3. Dynamic Active Navigation Indicator (ScrollSpy) --- */
    const sections = document.querySelectorAll('section[id]');
    const navItems = document.querySelectorAll('.nav-item');
    const mobileNavItems = document.querySelectorAll('.mobile-nav-item');

    function highlightActiveLink() {
        const scrollPosition = window.scrollY + 120; // offset for sticky navbar

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                // Update desktop links
                navItems.forEach(item => {
                    item.classList.remove('active');
                    if (item.getAttribute('href') === '#' + sectionId) {
                        item.classList.add('active');
                    }
                });

                // Update mobile drawer links
                mobileNavItems.forEach(item => {
                    item.classList.remove('active');
                    if (item.getAttribute('href') === '#' + sectionId) {
                        item.classList.add('active');
                    }
                });
            }
        });
    }

    window.addEventListener('scroll', highlightActiveLink);
    // Trigger on initial load to set default active tab
    highlightActiveLink();

    /* --- 4. Portfolio Filter System --- */
    const filterButtons = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            // Remove active class from current active button
            document.querySelector('.filter-btn.active').classList.remove('active');
            e.target.classList.add('active');

            const selectedFilter = e.target.getAttribute('data-filter');

            portfolioItems.forEach(item => {
                const itemCategory = item.getAttribute('data-category');

                // Smooth fade effects
                if (selectedFilter === 'all' || itemCategory === selectedFilter) {
                    item.style.display = 'block';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'scale(1)';
                    }, 50);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 300); // match transition speed
                }
            });
        });
    });

    /* --- 5. Clean Smooth Scroll with offset offset --- */
    const allAnchorLinks = document.querySelectorAll('a[href^="#"]');
    
    allAnchorLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href');
            if (targetId === '#') return;

            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                e.preventDefault();
                
                const navbarHeight = 70; // scrolled navbar height offset
                const targetPosition = targetSection.offsetTop - navbarHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    /* --- 6. Form Submit Interceptor --- */
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Collect info safely
            const name = document.getElementById('name').value;
            
            // Style-up a beautiful inline success card
            const contactCard = document.querySelector('.contact-card');
            contactCard.innerHTML = \`
                <div style="text-align: center; padding: 20px; display: flex; flex-direction: column; align-items: center; gap: 16px;">
                    <div style="width: 60px; height: 60px; background-color: var(--color-primary-glow); color: var(--color-primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px;">
                        <i class="fa-solid fa-circle-check"></i>
                    </div>
                    <h3 style="font-size: 22px; color: var(--color-text-title);">Thank you, \${name}!</h3>
                    <p style="font-size: 15px; color: var(--color-text-muted); line-height: 1.6;">Your message has been received successfully. Our design team will reach out to you shortly.</p>
                </div>
            \`;
        });
    }
});
`;

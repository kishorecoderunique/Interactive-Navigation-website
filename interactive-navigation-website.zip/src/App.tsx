import { useState, useEffect, useRef, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Compass, Code, FileCode, CheckCircle, ChevronRight, Menu, X, Monitor,
  Copy, Terminal, ExternalLink, Sliders, Smartphone, Palette, Send,
  Layout, MessageSquare, Briefcase, Zap, Globe, Wand2, RefreshCw, Sparkles,
  Check, Eye, Download, Info
} from 'lucide-react';
import { htmlCode, cssCode, jsCode } from './codeTemplates';

const heroImage = "/src/assets/images/hero_illustration_1782999694970.jpg";

export default function App() {
  // --- Navigation & Page Settings State ---
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // --- Dynamic Live Customizer State ---
  const [isGlass, setIsGlass] = useState(true);
  const [isShrinking, setIsShrinking] = useState(true);
  const [accentColor, setAccentColor] = useState<'emerald' | 'indigo' | 'violet' | 'amber'>('emerald');
  const [customizerOpen, setCustomizerOpen] = useState(false);

  // --- Portfolio Filtering State ---
  const [portfolioFilter, setPortfolioFilter] = useState<'all' | 'glass' | 'minimal' | 'dynamic'>('all');

  // --- Contact Form State ---
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [contactName, setContactName] = useState('');

  // --- Code Inspector / Exporter Drawer State ---
  const [showCodeDrawer, setShowCodeDrawer] = useState(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'html' | 'css' | 'js'>('html');
  const [copied, setCopied] = useState(false);

  // Accent theme config
  const colorThemes = {
    emerald: {
      primary: 'bg-emerald-500 hover:bg-emerald-600',
      text: 'text-emerald-500',
      border: 'border-emerald-500/20 focus:border-emerald-500',
      accentGlow: 'rgba(16, 185, 129, 0.15)',
      gradientText: 'from-emerald-400 via-emerald-500 to-teal-500',
      badge: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
      ring: 'focus:ring-emerald-500/20'
    },
    indigo: {
      primary: 'bg-indigo-500 hover:bg-indigo-600',
      text: 'text-indigo-500',
      border: 'border-indigo-500/20 focus:border-indigo-500',
      accentGlow: 'rgba(99, 102, 241, 0.15)',
      gradientText: 'from-indigo-400 via-indigo-500 to-violet-500',
      badge: 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20',
      ring: 'focus:ring-indigo-500/20'
    },
    violet: {
      primary: 'bg-violet-500 hover:bg-violet-600',
      text: 'text-violet-500',
      border: 'border-violet-500/20 focus:border-violet-500',
      accentGlow: 'rgba(139, 92, 246, 0.15)',
      gradientText: 'from-violet-400 via-violet-500 to-fuchsia-500',
      badge: 'bg-violet-500/10 text-violet-500 border-violet-500/20',
      ring: 'focus:ring-violet-500/20'
    },
    amber: {
      primary: 'bg-amber-500 hover:bg-amber-600',
      text: 'text-amber-500',
      border: 'border-amber-500/20 focus:border-amber-500',
      accentGlow: 'rgba(245, 158, 11, 0.15)',
      gradientText: 'from-amber-400 via-amber-500 to-orange-500',
      badge: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
      ring: 'focus:ring-amber-500/20'
    }
  };

  const currentTheme = colorThemes[accentColor];

  // --- Scroll Tracking for Navbar ---
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // --- Scroll Spy to Track Active Section ---
  useEffect(() => {
    const sections = ['home', 'about', 'services', 'portfolio', 'contact'];
    
    const handleScrollSpy = () => {
      const scrollPosition = window.scrollY + 120; // Scroll offset padding

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScrollSpy);
    // Initial trigger
    handleScrollSpy();
    return () => window.removeEventListener('scroll', handleScrollSpy);
  }, []);

  // --- Handle Smooth Scrolling with offset offset ---
  const handleScrollTo = (id: string) => {
    const target = document.getElementById(id);
    if (target) {
      const offset = isShrinking ? 70 : 96; // match navigation heights
      const targetPos = target.offsetTop - offset;
      
      window.scrollTo({
        top: targetPos,
        behavior: 'smooth'
      });
      setActiveSection(id);
      setMobileMenuOpen(false);
    }
  };

  // --- Copy to Clipboard Handler ---
  const handleCopyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  // --- Contact Form Submission Handler ---
  const handleFormSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setFormSubmitted(true);
    }, 1500);
  };

  // Portfolio projects data
  const portfolioItems = [
    { id: 1, category: 'glass', title: 'Glassmorphic Panel', desc: 'Blur-heavy administrative console', seed: 'glass1' },
    { id: 2, category: 'minimal', title: 'Slate Workspace', desc: 'Sleek, high-contrast creative deck', seed: 'min1' },
    { id: 3, category: 'dynamic', title: 'Nebula Portal', desc: 'Interactive navigation with particle physics', seed: 'dyn1' },
    { id: 4, category: 'glass', title: 'Aurora Settings', desc: 'Soft-glowing system components', seed: 'glass2' },
    { id: 5, category: 'minimal', title: 'Editorial Hub', desc: 'High-contrast, elegant serif layouts', seed: 'min2' },
    { id: 6, category: 'dynamic', title: 'Responsive Grid', desc: 'Infinite masonry feed with transitions', seed: 'dyn2' }
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-700 font-sans antialiased relative">
      
      {/* ==========================================================================
         Header / Sticky Navigation Bar
         ========================================================================== */}
      <header
        id="navbar"
        className={`fixed top-0 left-0 w-full z-40 transition-all duration-400 flex items-center ${
          isShrinking && scrolled ? 'h-16' : 'h-24'
        } ${
          isGlass 
            ? scrolled 
              ? 'bg-white/85 border-b border-slate-200/50 backdrop-blur-md shadow-lg shadow-slate-900/5' 
              : 'bg-white/70 border-b border-white/20 backdrop-blur-md'
            : scrolled 
              ? 'bg-white border-b border-slate-200 shadow-md' 
              : 'bg-white border-b border-slate-100'
        }`}
      >
        <div className="max-w-7xl w-full mx-auto px-6 flex items-center justify-between">
          
          {/* Logo on the left */}
          <button 
            id="logo"
            onClick={() => handleScrollTo('home')} 
            className="flex items-center gap-3 group cursor-pointer text-left"
          >
            <div className={`w-9 h-9 ${currentTheme.primary} text-white rounded-xl flex items-center justify-center shadow-lg transition-transform duration-300 group-hover:scale-110`}>
              <Compass className="w-5 h-5" />
            </div>
            <span className="font-display font-bold text-xl text-slate-900 tracking-tight">
              Nav<span className={currentTheme.text}>Craft</span>
            </span>
          </button>

          {/* Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-8">
            {['home', 'about', 'services', 'portfolio', 'contact'].map((item) => (
              <button
                key={item}
                onClick={() => handleScrollTo(item)}
                className={`text-[15px] font-medium py-2 px-1 relative transition-all duration-300 capitalize cursor-pointer hover:scale-105 active:scale-95 ${
                  activeSection === item ? currentTheme.text : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {item}
                {activeSection === item && (
                  <motion.div
                    layoutId="activeUnderline"
                    className={`absolute bottom-0 left-0 w-full h-[2px] ${
                      accentColor === 'emerald' ? 'bg-emerald-500' :
                      accentColor === 'indigo' ? 'bg-indigo-500' :
                      accentColor === 'violet' ? 'bg-violet-500' : 'bg-amber-500'
                    }`}
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* CTA Buttons (Desktop) */}
          <div className="hidden md:flex items-center gap-4">
            <button className="text-slate-600 hover:text-slate-900 font-semibold text-sm py-2 px-4 border border-slate-200 hover:border-slate-400 rounded-xl transition-all duration-300 hover:bg-slate-50 cursor-pointer active:scale-95">
              Log In
            </button>
            <button className={`text-white font-semibold text-sm py-2.5 px-5 rounded-xl transition-all duration-300 ${currentTheme.primary} shadow-lg active:scale-95 cursor-pointer`}>
              Sign Up
            </button>
          </div>

          {/* Hamburger Menu (Mobile Toggle) */}
          <button
            id="hamburger-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden flex flex-col justify-between w-6 h-5 bg-transparent border-none cursor-pointer z-50 focus:outline-none"
            aria-label="Toggle navigation"
          >
            <span className={`w-full h-[2px] bg-slate-800 rounded-full transition-all duration-300 origin-left ${mobileMenuOpen ? 'rotate-45 translate-y-[2px]' : ''}`} />
            <span className={`w-full h-[2px] bg-slate-800 rounded-full transition-all duration-300 ${mobileMenuOpen ? 'opacity-0' : 'opacity-100'}`} />
            <span className={`w-full h-[2px] bg-slate-800 rounded-full transition-all duration-300 origin-left ${mobileMenuOpen ? '-rotate-45 -translate-y-[2px]' : ''}`} />
          </button>
        </div>

        {/* Mobile Menu Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="absolute top-full left-0 w-full bg-white border-b border-slate-200/80 shadow-2xl px-6 py-8 flex flex-col gap-6 md:hidden"
            >
              <nav className="flex flex-col gap-4">
                {['home', 'about', 'services', 'portfolio', 'contact'].map((item) => (
                  <button
                    key={item}
                    onClick={() => handleScrollTo(item)}
                    className={`text-base font-semibold py-2.5 text-left border-b border-slate-100 capitalize ${
                      activeSection === item ? currentTheme.text : 'text-slate-700'
                    }`}
                  >
                    {item}
                  </button>
                ))}
              </nav>
              <div className="flex flex-col gap-3">
                <button className="w-full text-slate-700 font-semibold text-sm py-3 border border-slate-200 rounded-xl hover:bg-slate-50 transition-all cursor-pointer">
                  Log In
                </button>
                <button className={`w-full text-white font-semibold text-sm py-3 rounded-xl transition-all shadow-md ${currentTheme.primary} cursor-pointer`}>
                  Sign Up
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* ==========================================================================
         Landing Page Content
         ========================================================================== */}
      <main className="overflow-x-hidden">
        
        {/* 1. Hero Section */}
        <section
          id="home"
          className="relative pt-44 pb-32 min-h-screen flex items-center bg-slate-900 text-white overflow-hidden"
        >
          {/* Neon Gradient Ambient Orbs */}
          <div className="absolute top-1/4 left-10 w-96 h-96 rounded-full bg-emerald-500/10 blur-[120px] pointer-events-none" />
          <div className="absolute bottom-1/4 right-10 w-96 h-96 rounded-full bg-blue-500/10 blur-[120px] pointer-events-none" />

          <div className="max-w-7xl w-full mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
            
            <div className="lg:col-span-7 flex flex-col items-start">
              <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider mb-6 border ${currentTheme.badge}`}>
                <Sparkles className="w-3 h-3" /> Next-Gen Interface Design
              </span>
              <h1 className="font-display font-bold text-5xl md:text-6xl text-white leading-[1.1] mb-6 tracking-tight">
                Experience Seamless <span className={`bg-gradient-to-r ${currentTheme.gradientText} bg-clip-text text-transparent`}>Navigation</span>
              </h1>
              <p className="text-slate-400 text-lg md:text-xl mb-10 max-w-xl leading-relaxed">
                Elevate your web layouts with smooth scroll animations, high-fidelity glassmorphism, responsive triggers, and scroll-to active highlight tracking.
              </p>
              <div className="flex flex-wrap gap-4 w-full sm:w-auto">
                <button 
                  onClick={() => handleScrollTo('services')}
                  className={`w-full sm:w-auto text-white font-bold py-4 px-8 rounded-xl transition-all duration-300 hover:-translate-y-1 shadow-lg cursor-pointer ${currentTheme.primary}`}
                >
                  Explore Services
                </button>
                <button 
                  onClick={() => handleScrollTo('about')}
                  className="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-white font-bold py-4 px-8 rounded-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer"
                >
                  Learn More
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 flex justify-center">
              <div className="relative w-full max-w-sm aspect-video sm:aspect-square">
                {/* Floating Mockup Display Card */}
                <motion.div
                  animate={{ y: [0, -12, 0] }}
                  transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
                  className="w-full h-full bg-slate-800/40 border border-white/10 backdrop-blur-xl rounded-3xl p-6 shadow-2xl flex flex-col justify-between gap-6"
                >
                  <div className="flex gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-red-400" />
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  </div>
                  
                  {/* Generated Illustration Embed */}
                  <div className="w-full h-48 rounded-xl overflow-hidden relative border border-slate-700 bg-slate-950/50">
                    <img 
                      src={heroImage} 
                      alt="NavCraft Hero Abstract Illustration" 
                      className="w-full h-full object-cover opacity-85 hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent" />
                    <div className="absolute bottom-4 left-4 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-[10px] font-mono text-emerald-400 font-semibold uppercase tracking-wider">Live Preview System Active</span>
                    </div>
                  </div>

                  <div className="flex flex-col gap-3">
                    <div className="h-4 bg-white/10 rounded-md w-3/4" />
                    <div className="h-3 bg-white/5 rounded-md w-1/2" />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-3">
                    <div className="aspect-square rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400"><Layout className="w-4 h-4" /></div>
                    <div className="aspect-square rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400"><Sliders className="w-4 h-4" /></div>
                    <div className="aspect-square rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400"><Code className="w-4 h-4" /></div>
                  </div>
                </motion.div>
              </div>
            </div>

          </div>
        </section>

        {/* 2. About Section */}
        <section id="about" className="py-28 bg-white border-b border-slate-100">
          <div className="max-w-7xl w-full mx-auto px-6">
            
            <div className="text-center max-w-2xl mx-auto mb-20">
              <span className={`text-xs font-bold uppercase tracking-widest block mb-3 ${currentTheme.text}`}>About Our Craft</span>
              <h2 className="font-display font-bold text-4xl text-slate-900 mb-4 tracking-tight">Designed for Visual Perfection</h2>
              <p className="text-slate-500 text-base md:text-lg">We build premium interaction layers that connect human intuition with technical elegance.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { icon: Sparkles, title: 'Pixel Perfect', desc: 'Every element is aligned to a strict layout grid with balanced vertical rhythm, precise letter-tracking, and rich margin-scaling.' },
                { icon: Zap, title: 'Lightning Fast', desc: 'Fully optimized CSS micro-transitions and minimal JavaScript overhead guarantee interactions execute smoothly at a locked 60fps.' },
                { icon: Smartphone, title: 'Universal Layout', desc: 'Adapts fluidly across screen width boundaries, transitioning from massive workstation displays down to mobile handheld touchpoints.' }
              ].map((card, i) => (
                <div 
                  key={i} 
                  className="bg-white border border-slate-100 rounded-2xl p-8 hover:-translate-y-2 hover:shadow-xl hover:border-slate-200 hover:shadow-slate-200/50 transition-all duration-300 flex flex-col items-start text-left group"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 ${currentTheme.badge}`}>
                    <card.icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-display font-bold text-xl text-slate-900 mb-3">{card.title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">{card.desc}</p>
                </div>
              ))}
            </div>

          </div>
        </section>

        {/* 3. Services Section */}
        <section id="services" className="py-28 bg-slate-50 border-b border-slate-100">
          <div className="max-w-7xl w-full mx-auto px-6">
            
            <div className="text-center max-w-2xl mx-auto mb-20">
              <span className={`text-xs font-bold uppercase tracking-widest block mb-3 ${currentTheme.text}`}>What We Do</span>
              <h2 className="font-display font-bold text-4xl text-slate-900 mb-4 tracking-tight">Our Navigation Services</h2>
              <p className="text-slate-500 text-base md:text-lg">Tailored interaction layers designed and engineered specifically for your web layouts.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              <div className="lg:col-span-2 bg-white border border-slate-100 rounded-3xl p-8 md:p-10 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-8 hover:-translate-y-1 hover:shadow-md transition-all duration-300 group">
                <div className="flex flex-col items-start text-left max-w-md">
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider mb-4 ${currentTheme.badge}`}>Premium Feature</span>
                  <h3 className="font-display font-bold text-2xl text-slate-900 mb-3">Custom Navigation Audits</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">We review your user conversion journeys, heatmaps, and information hierarchies to design customized sticky headers, drop-downs, and sidebar layouts.</p>
                </div>
                <div className="text-slate-200 group-hover:scale-110 group-hover:text-emerald-500/20 transition-all duration-300 hidden md:block">
                  <Globe className="w-24 h-24 stroke-[1]" />
                </div>
              </div>

              <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm flex flex-col justify-between hover:-translate-y-1 hover:shadow-md transition-all duration-300 group">
                <div className="flex flex-col items-start text-left">
                  <h3 className="font-display font-bold text-xl text-slate-900 mb-3">Micro-Interactions</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">Delightful, responsive animations for buttons, sliders, links, and switches that elevate user satisfaction and interface feel.</p>
                </div>
                <div className="mt-8 self-end text-slate-200 group-hover:text-indigo-500/20 transition-colors duration-300">
                  <Wand2 className="w-12 h-12" />
                </div>
              </div>

              <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm flex flex-col justify-between hover:-translate-y-1 hover:shadow-md transition-all duration-300 group">
                <div className="flex flex-col items-start text-left">
                  <h3 className="font-display font-bold text-xl text-slate-900 mb-3">Responsive Auditing</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">Ensuring complicated navigation grids degrade cleanly into hamburger sliding bars or compact bottom-nav elements for hand-held clients.</p>
                </div>
                <div className="mt-8 self-end text-slate-200 group-hover:text-violet-500/20 transition-colors duration-300">
                  <Monitor className="w-12 h-12" />
                </div>
              </div>

              <div className="lg:col-span-2 bg-white border border-slate-100 rounded-3xl p-8 md:p-10 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-8 hover:-translate-y-1 hover:shadow-md transition-all duration-300 group">
                <div className="flex flex-col items-start text-left max-w-md">
                  <h3 className="font-display font-bold text-2xl text-slate-900 mb-3">Interaction Systems</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">Developing consistent, responsive interaction guidelines so your engineering team can deploy menus, buttons, and drawers across applications seamlessly.</p>
                </div>
                <div className="text-slate-200 group-hover:scale-110 group-hover:text-amber-500/20 transition-all duration-300 hidden md:block">
                  <Layout className="w-24 h-24 stroke-[1]" />
                </div>
              </div>

            </div>

          </div>
        </section>

        {/* 4. Portfolio Section */}
        <section id="portfolio" className="py-28 bg-white border-b border-slate-100">
          <div className="max-w-7xl w-full mx-auto px-6">
            
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className={`text-xs font-bold uppercase tracking-widest block mb-3 ${currentTheme.text}`}>Featured Work</span>
              <h2 className="font-display font-bold text-4xl text-slate-900 mb-4 tracking-tight">Visual Showcase</h2>
              <p className="text-slate-500 text-base md:text-lg">Explore a selection of high-performance glassmorphic layouts we have built.</p>
            </div>

            {/* Filter Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
              {[
                { id: 'all', label: 'All Projects' },
                { id: 'glass', label: 'Glassmorphism' },
                { id: 'minimal', label: 'Minimalist' },
                { id: 'dynamic', label: 'Dynamic UI' }
              ].map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setPortfolioFilter(filter.id as any)}
                  className={`text-sm font-semibold py-2.5 px-6 rounded-full border transition-all duration-300 cursor-pointer ${
                    portfolioFilter === filter.id
                      ? `${currentTheme.primary} border-transparent text-white shadow-md`
                      : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>

            {/* Filterable Portfolio Grid */}
            <motion.div 
              layout
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              <AnimatePresence mode="popLayout">
                {portfolioItems
                  .filter(item => portfolioFilter === 'all' || item.category === portfolioFilter)
                  .map((item) => (
                    <motion.div
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.3 }}
                      key={item.id}
                      className="group bg-slate-950 rounded-2xl overflow-hidden relative shadow-md hover:shadow-xl transition-all duration-500 aspect-[3/2] cursor-pointer"
                    >
                      <img
                        src={`https://picsum.photos/seed/${item.seed}/600/400`}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-90 group-hover:opacity-75"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex flex-col justify-end p-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-emerald-400 mb-2">{item.category} Layout</span>
                        <h3 className="font-display font-bold text-xl text-white mb-1">{item.title}</h3>
                        <p className="text-slate-300 text-xs leading-relaxed">{item.desc}</p>
                      </div>
                    </motion.div>
                  ))}
              </AnimatePresence>
            </motion.div>

          </div>
        </section>

        {/* 5. Contact Section */}
        <section id="contact" className="py-28 bg-slate-50 relative overflow-hidden">
          
          <div className="max-w-7xl w-full mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
            
            <div className="flex flex-col items-start text-left">
              <span className={`text-xs font-bold uppercase tracking-widest block mb-3 ${currentTheme.text}`}>Get in Touch</span>
              <h2 className="font-display font-bold text-4xl text-slate-900 mb-6 tracking-tight leading-tight">Let's craft something amazing together</h2>
              <p className="text-slate-500 text-base md:text-lg mb-10 leading-relaxed">
                Have an active design project or need expert interface engineering consultation? Submit our glassmorphic form below and our UI design leads will reply within 24 hours.
              </p>
              
              <div className="flex flex-col gap-6 w-full">
                <div className="flex items-center gap-4 text-slate-700">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${currentTheme.badge}`}>
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <span className="font-medium text-sm sm:text-base">design@navcraft.io</span>
                </div>
                <div className="flex items-center gap-4 text-slate-700">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${currentTheme.badge}`}>
                    <Globe className="w-5 h-5" />
                  </div>
                  <span className="font-medium text-sm sm:text-base">San Francisco, California, US</span>
                </div>
              </div>
            </div>

            <div className="flex justify-center w-full">
              <div className="bg-white border border-slate-200/60 rounded-3xl p-8 shadow-xl shadow-slate-200/50 w-full max-w-lg min-h-[400px] flex flex-col justify-center relative overflow-hidden">
                
                <AnimatePresence mode="wait">
                  {!formSubmitted ? (
                    <motion.form
                      key="contact-form"
                      initial={{ opacity: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      onSubmit={handleFormSubmit}
                      className="flex flex-col gap-5 text-left"
                    >
                      <div className="flex flex-col gap-2">
                        <label htmlFor="react-name" className="text-[11px] font-bold text-slate-900 uppercase tracking-wider">Full Name</label>
                        <input
                          type="text"
                          id="react-name"
                          required
                          value={contactName}
                          onChange={(e) => setContactName(e.target.value)}
                          placeholder="John Doe"
                          className={`font-sans text-sm p-3.5 rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:bg-white focus:ring-4 ${currentTheme.border} ${currentTheme.ring} transition-all duration-300`}
                        />
                      </div>

                      <div className="flex flex-col gap-2">
                        <label htmlFor="react-email" className="text-[11px] font-bold text-slate-900 uppercase tracking-wider">Email Address</label>
                        <input
                          type="email"
                          id="react-email"
                          required
                          placeholder="john@example.com"
                          className={`font-sans text-sm p-3.5 rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:bg-white focus:ring-4 ${currentTheme.border} ${currentTheme.ring} transition-all duration-300`}
                        />
                      </div>

                      <div className="flex flex-col gap-2">
                        <label htmlFor="react-message" className="text-[11px] font-bold text-slate-900 uppercase tracking-wider">Project Scope</label>
                        <textarea
                          id="react-message"
                          required
                          rows={4}
                          placeholder="Tell us about your project timeline and requirements..."
                          className={`font-sans text-sm p-3.5 rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:bg-white focus:ring-4 ${currentTheme.border} ${currentTheme.ring} transition-all duration-300`}
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className={`w-full text-white font-bold py-3.5 px-6 rounded-xl transition-all duration-300 shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 ${currentTheme.primary}`}
                      >
                        {isSubmitting ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" /> Sending Message...
                          </>
                        ) : (
                          <>
                            <Send className="w-4 h-4" /> Send Message
                          </>
                        )}
                      </button>
                    </motion.form>
                  ) : (
                    <motion.div
                      key="success-card"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.4, type: 'spring' }}
                      className="flex flex-col items-center justify-center text-center py-8 px-4"
                    >
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 text-emerald-500 bg-emerald-500/10`}>
                        <CheckCircle className="w-10 h-10" />
                      </div>
                      <h3 className="font-display font-bold text-2xl text-slate-900 mb-3">Thank you, {contactName}!</h3>
                      <p className="text-slate-500 text-sm max-w-xs leading-relaxed mb-6">
                        Your message has been intercepted successfully. Our interface team will reach out to your inbox within 24 hours.
                      </p>
                      <button
                        onClick={() => {
                          setFormSubmitted(false);
                          setContactName('');
                        }}
                        className="text-xs font-semibold py-2 px-4 border border-slate-200 rounded-lg hover:border-slate-300 transition-all text-slate-600 hover:text-slate-900 cursor-pointer"
                      >
                        Send Another Message
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>
            </div>

          </div>
        </section>

      </main>

      {/* ==========================================================================
         Aesthetic Live Playground Controller Panel (Sticky Bottom-Left Widget)
         ========================================================================== */}
      <div className="fixed bottom-6 left-6 z-40 flex flex-col gap-3">
        <AnimatePresence mode="wait">
          {!customizerOpen ? (
            /* Collapsed - Simple Elegant Square Button */
            <motion.button
              key="collapsed-customizer"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              onClick={() => setCustomizerOpen(true)}
              className="w-12 h-12 bg-slate-900/95 text-white border border-slate-800 hover:border-slate-700 backdrop-blur-md rounded-xl flex items-center justify-center shadow-xl cursor-pointer hover:scale-105 transition-all duration-300 group"
              title="Customize Theme & Layout"
              id="customizer-toggle-btn"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Sliders className={`w-5 h-5 transition-transform duration-300 group-hover:rotate-12 ${currentTheme.text}`} />
            </motion.button>
          ) : (
            /* Expanded - Interactive Customizer Card */
            <motion.div
              key="expanded-customizer"
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="bg-slate-900/95 text-white border border-slate-800 backdrop-blur-md rounded-2xl p-4 shadow-2xl max-w-[280px] sm:max-w-xs flex flex-col gap-3.5"
              id="customizer-panel-card"
            >
              <div className="flex items-center justify-between gap-4 border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <Sliders className={`w-4 h-4 ${currentTheme.text}`} />
                  <span className="font-display font-bold text-xs uppercase tracking-wider text-slate-200">Interactive Customizer</span>
                </div>
                <button
                  onClick={() => setCustomizerOpen(false)}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                  title="Collapse"
                  id="customizer-collapse-btn"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Accent Color picker */}
              <div className="flex flex-col gap-1.5 text-left">
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Accent Theme</span>
                <div className="flex gap-2.5">
                  {(['emerald', 'indigo', 'violet', 'amber'] as const).map((color) => (
                    <button
                      key={color}
                      onClick={() => setAccentColor(color)}
                      className={`w-6 h-6 rounded-full border-2 transition-all cursor-pointer ${
                        color === 'emerald' ? 'bg-emerald-500 border-emerald-300' :
                        color === 'indigo' ? 'bg-indigo-500 border-indigo-300' :
                        color === 'violet' ? 'bg-violet-500 border-violet-300' : 'bg-amber-500 border-amber-300'
                      } ${accentColor === color ? 'scale-125 ring-2 ring-white/50' : 'opacity-70 hover:opacity-100'}`}
                      title={`${color} accent`}
                      id={`accent-${color}-btn`}
                    />
                  ))}
                </div>
              </div>

              {/* Toggle Shrinkage */}
              <div className="flex items-center justify-between gap-6 text-left">
                <div className="flex flex-col">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Shrinking Scroll</span>
                  <span className="text-[9px] text-slate-500 font-sans">Height drops on scroll</span>
                </div>
                <button
                  onClick={() => setIsShrinking(!isShrinking)}
                  className={`w-10 h-6 rounded-full p-1 transition-all cursor-pointer ${isShrinking ? 'bg-emerald-500' : 'bg-slate-700'}`}
                  id="toggle-shrink-btn"
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${isShrinking ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>

              {/* Toggle Glassmorphic Backdrop */}
              <div className="flex items-center justify-between gap-6 text-left">
                <div className="flex flex-col">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Glassmorphism</span>
                  <span className="text-[9px] text-slate-500 font-sans">Translucent blur header</span>
                </div>
                <button
                  onClick={() => setIsGlass(!isGlass)}
                  className={`w-10 h-6 rounded-full p-1 transition-all cursor-pointer ${isGlass ? 'bg-emerald-500' : 'bg-slate-700'}`}
                  id="toggle-glass-btn"
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${isGlass ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Source Code Viewer Trigger (Bottom Right Floating Button) */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setShowCodeDrawer(true)}
          className={`flex items-center gap-2 py-3 px-5 rounded-full font-bold text-sm text-white shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer bg-slate-900 border border-slate-800 hover:bg-slate-800`}
        >
          <Code className="w-4 h-4 text-emerald-400" /> Export Code
        </button>
      </div>

      {/* ==========================================================================
         Aesthetic Slide-out Source Code Drawer / Mock IDE
         ========================================================================== */}
      <AnimatePresence>
        {showCodeDrawer && (
          <>
            {/* Dark overlay backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCodeDrawer(false)}
              className="fixed inset-0 bg-slate-950 z-50 cursor-pointer"
            />

            {/* Sidebar Slide-out Drawer */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 180 }}
              className="fixed top-0 right-0 h-screen w-full max-w-4xl bg-[#1e293b] shadow-2xl z-50 flex flex-col text-slate-200 overflow-hidden font-mono"
            >
              {/* Drawer Top Header */}
              <div className="bg-[#0f172a] px-6 py-4 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Terminal className="w-5 h-5 text-emerald-400" />
                  <h3 className="font-display font-bold text-base text-slate-100 uppercase tracking-wider">Source Code Exporter</h3>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-sans uppercase font-semibold">Vanilla Files Included</span>
                  <button
                    onClick={() => setShowCodeDrawer(false)}
                    className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Layout Split: Left File Explorer Tree, Right Code Editor */}
              <div className="flex-1 flex overflow-hidden">
                
                {/* Left Mini Sidebar - Folder Structure */}
                <div className="hidden sm:flex flex-col w-56 bg-[#0f172a]/60 border-r border-slate-800/80 p-4 select-none">
                  <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-4">Workspace Files</div>
                  <div className="flex flex-col gap-2.5 text-xs text-slate-400">
                    <div className="flex items-center gap-2 py-1 px-1.5 rounded hover:bg-slate-800/40 cursor-pointer">
                      <Layout className="w-3.5 h-3.5 text-slate-500" />
                      <span className="font-semibold text-slate-500">vanilla/</span>
                    </div>
                    <button
                      onClick={() => setActiveCodeTab('html')}
                      className={`flex items-center gap-2 py-1 px-3 ml-2.5 rounded text-left cursor-pointer transition-colors ${activeCodeTab === 'html' ? 'bg-[#0f172a] text-emerald-400 border-l-2 border-emerald-500' : 'hover:bg-slate-800/40 hover:text-slate-200'}`}
                    >
                      <FileCode className="w-3.5 h-3.5 text-orange-400" />
                      <span>index.html</span>
                    </button>
                    <button
                      onClick={() => setActiveCodeTab('css')}
                      className={`flex items-center gap-2 py-1 px-3 ml-2.5 rounded text-left cursor-pointer transition-colors ${activeCodeTab === 'css' ? 'bg-[#0f172a] text-emerald-400 border-l-2 border-emerald-500' : 'hover:bg-slate-800/40 hover:text-slate-200'}`}
                    >
                      <Code className="w-3.5 h-3.5 text-blue-400" />
                      <span>style.css</span>
                    </button>
                    <button
                      onClick={() => setActiveCodeTab('js')}
                      className={`flex items-center gap-2 py-1 px-3 ml-2.5 rounded text-left cursor-pointer transition-colors ${activeCodeTab === 'js' ? 'bg-[#0f172a] text-emerald-400 border-l-2 border-emerald-500' : 'hover:bg-slate-800/40 hover:text-slate-200'}`}
                    >
                      <Terminal className="w-3.5 h-3.5 text-yellow-400" />
                      <span>script.js</span>
                    </button>
                  </div>

                  {/* Info helper info box */}
                  <div className="mt-auto bg-slate-900/50 border border-slate-800/40 rounded-xl p-3.5 flex flex-col gap-2 text-left text-[11px] font-sans leading-relaxed text-slate-400">
                    <div className="flex items-center gap-1.5 text-slate-300 font-bold uppercase tracking-wider">
                      <Info className="w-3.5 h-3.5 text-blue-400" /> Instructions
                    </div>
                    <span>Copy these three codes into separate local files, or locate them in the physical <b>/vanilla</b> folder of this project's directory tree.</span>
                  </div>
                </div>

                {/* Right Code Display Canvas */}
                <div className="flex-1 flex flex-col overflow-hidden bg-[#0f172a]/30">
                  
                  {/* Editor Tab Headers (For mobile navigation or desktop visual harmony) */}
                  <div className="bg-[#0f172a]/40 border-b border-slate-800 px-4 flex items-center justify-between h-12">
                    <div className="flex items-center gap-2">
                      {['html', 'css', 'js'].map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setActiveCodeTab(tab as any)}
                          className={`px-4 h-12 flex items-center gap-2 text-xs font-semibold cursor-pointer border-b-2 capitalize transition-all ${
                            activeCodeTab === tab
                              ? 'border-emerald-500 text-slate-100 bg-[#0f172a]'
                              : 'border-transparent text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            tab === 'html' ? 'bg-orange-400' :
                            tab === 'css' ? 'bg-blue-400' : 'bg-yellow-400'
                          }`} />
                          {tab === 'html' ? 'index.html' : tab === 'css' ? 'style.css' : 'script.js'}
                        </button>
                      ))}
                    </div>

                    {/* Copy Button inside Tab bar */}
                    <button
                      onClick={() => handleCopyCode(
                        activeCodeTab === 'html' ? htmlCode :
                        activeCodeTab === 'css' ? cssCode : jsCode
                      )}
                      className={`flex items-center gap-1.5 py-1.5 px-3.5 rounded-lg text-xs font-bold font-sans cursor-pointer transition-all ${
                        copied 
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
                          : 'bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-200'
                      }`}
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" /> Copy Code
                        </>
                      )}
                    </button>
                  </div>

                  {/* Code Block viewer body */}
                  <div className="flex-1 overflow-auto p-6 text-xs text-slate-300 text-left whitespace-pre select-all font-mono leading-relaxed bg-[#0b0f19]">
                    <code>
                      {activeCodeTab === 'html' ? htmlCode : activeCodeTab === 'css' ? cssCode : jsCode}
                    </code>
                  </div>

                </div>

              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Small aesthetic copyright footer */}
      <footer className="bg-slate-900 border-t border-slate-800/60 py-10 text-center text-slate-500 text-sm">
        <div className="max-w-7xl w-full mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>&copy; 2026 NavCraft. All rights reserved. Interactive showcase demo system.</p>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-mono text-[11px] text-slate-400">AI STUDIO VERIFIED BUILD</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
